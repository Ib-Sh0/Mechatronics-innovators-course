/*
  CareLink - Emergency Call Station
  ---------------------------------
  A help button for an elderly person.

  Press the big button  -> ALERT (red light blinking + beeping)
  Press the reset button -> short chime, then back to READY

  The 3 states:
   READY - green light, waiting for a press
   ALERT - red light blinking + buzzer beeping
   RESET - blue light + chime, then back to READY

  Holding the emergency button for 1.2 s = PRIORITY alert
  (faster blinking and faster beeping).

  Wiring:
   D2  emergency button (other leg to GND)
   D3  reset button     (other leg to GND)
   D5  RGB led red   (through 220 ohm resistor)
   D6  RGB led green (through 220 ohm resistor)
   D9  RGB led blue  (through 220 ohm resistor)
   D10 buzzer (+)  (minus to GND)
*/

// ---------- pins ----------
const int BUTTON_PIN = 2;      // emergency button
const int RESET_PIN  = 3;      // reset button
const int RED_PIN    = 5;      // rgb led
const int GREEN_PIN  = 6;
const int BLUE_PIN   = 9;
const int BUZZER_PIN = 10;

// ---------- settings ----------
const bool RGB_BACKWARDS = false;  // set true if the led is common anode
const int BRIGHT = 200;            // led brightness (0 - 255)
const int DEBOUNCE = 20;           // ms to wait before trusting a press
const int LONG_PRESS = 1200;       // hold this long = priority alert

// the three states
const int ST_READY = 0;
const int ST_ALERT = 1;
const int ST_RESET = 2;

int state = ST_RESET;              // the device boots into RESET
bool priority = false;             // true = fast alert pattern

// ---------- button variables ----------
bool emergencyDown = false;        // is the emergency button held?
unsigned long emergencyStart = 0;  // when the current press started
bool resetDown = false;

// ---------- alert timing ----------
unsigned long blinkTimer = 0;
bool redOn = true;
unsigned long beepTimer = 0;
bool beeping = true;

// ---------- reset timing ----------
unsigned long resetTimer = 0;

// ---------------------------------------------------------------
void setup() {
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);   // button goes between pin and GND
  pinMode(RESET_PIN, INPUT_PULLUP);

  Serial.begin(9600);
  Serial.println("CareLink Emergency Call Station");

  // simple wiring check: a button should not be pressed at startup
  if (digitalRead(BUTTON_PIN) == LOW) Serial.println("WARNING: emergency button stuck LOW - check wiring");
  if (digitalRead(RESET_PIN) == LOW)  Serial.println("WARNING: reset button stuck LOW - check wiring");

  goReset();   // boot: blue light + chime, then ready
}

// ---------------------------------------------------------------
void loop() {
  // read the buttons
  emergencyDown = buttonPressed(BUTTON_PIN);
  resetDown = buttonPressed(RESET_PIN);

  if (state == ST_READY) {
    // waiting for the emergency button
    if (emergencyDown) {
      if (emergencyStart == 0) emergencyStart = millis();   // press began
      if (millis() - emergencyStart > LONG_PRESS) {
        priority = true;          // held a long time = priority alert
        goAlert();
      }
    } else {
      if (emergencyStart != 0) {  // quick press (released early)
        priority = false;
        goAlert();
      }
      emergencyStart = 0;
    }
  }
  else if (state == ST_ALERT) {
    // how fast we blink and beep (priority = faster)
    int blinkSpeed = 400;
    int beepOn = 120;
    int beepOff = 480;
    if (priority) {
      blinkSpeed = 150;
      beepOn = 60;
      beepOff = 140;
    }

    // blink the red light
    if (millis() - blinkTimer > blinkSpeed) {
      blinkTimer = millis();
      redOn = !redOn;
      if (redOn) setRgb(BRIGHT, 0, 0);
      else setRgb(0, 0, 0);
    }

    // beep pattern: on for beepOn, off for beepOff
    if (beeping && millis() - beepTimer > beepOn) {
      noTone(BUZZER_PIN);
      beeping = false;
      beepTimer = millis();
    }
    if (!beeping && millis() - beepTimer > beepOff) {
      tone(BUZZER_PIN, 2000);
      beeping = true;
      beepTimer = millis();
    }

    if (resetDown) goReset();     // caregiver pressed reset
  }
  else if (state == ST_RESET) {
    // blue light and chime already happened in goReset(), just wait
    if (millis() - resetTimer > 900) {
      state = ST_READY;
      setRgb(0, BRIGHT, 0);       // green = ready
      Serial.println("READY - waiting for a press");
    }
  }
}

// ---------------------------------------------------------------
// set the rgb led color (r, g, b each 0 - 255)
void setRgb(int r, int g, int b) {
  if (RGB_BACKWARDS) {            // common anode led works backwards
    r = 255 - r;
    g = 255 - g;
    b = 255 - b;
  }
  analogWrite(RED_PIN, r);
  analogWrite(GREEN_PIN, g);
  analogWrite(BLUE_PIN, b);
}

// ---------------------------------------------------------------
// simple debounce: if the pin reads LOW, wait a moment and check again
bool buttonPressed(int pin) {
  if (digitalRead(pin) == LOW) {
    delay(DEBOUNCE);
    if (digitalRead(pin) == LOW) return true;
  }
  return false;
}

// ---------------------------------------------------------------
// switch into ALERT: red light + beeping
void goAlert() {
  state = ST_ALERT;
  emergencyStart = 0;
  blinkTimer = millis();
  beepTimer = millis();
  redOn = true;
  beeping = true;
  setRgb(BRIGHT, 0, 0);           // start on red
  tone(BUZZER_PIN, 2000);         // start beeping
  if (priority) Serial.println("ALERT (PRIORITY) - help is needed");
  else Serial.println("ALERT - help is needed");
}

// ---------------------------------------------------------------
// switch into RESET: blue light + chime, then back to ready
void goReset() {
  state = ST_RESET;
  resetTimer = millis();
  setRgb(0, 0, BRIGHT);           // blue
  tone(BUZZER_PIN, 1200);         // chime: two short notes
  delay(150);
  tone(BUZZER_PIN, 1800);
  delay(150);
  noTone(BUZZER_PIN);
  Serial.println("RESET - going back to ready");
}
